#ifndef boolean_h
#define boolean_h

/* Definisi type boolean */
#define true 1
#define false 0
#define boolean unsigned char

#endif
